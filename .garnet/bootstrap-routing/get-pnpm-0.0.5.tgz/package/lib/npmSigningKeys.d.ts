export declare const NPM_SIGNING_KEYS: readonly [{
    readonly expires: null;
    readonly keyid: "SHA256:DhQ8wR5APBvFHLF/+Tc+AYvPOdTpcIDqOhxsBHRwC7U";
    readonly keytype: "ecdsa-sha2-nistp256";
    readonly scheme: "ecdsa-sha2-nistp256";
    readonly key: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEY6Ya7W++7aUPzvMTrezH6Ycx3c+HOKYCcNGybJZSCJq/fd7Qa8uuAKtdIkUQtQiEKERhAmE5lMMJhP8OkDOa2g==";
}, {
    readonly expires: "2025-01-29T00:00:00.000Z";
    readonly keyid: "SHA256:jl3bwswu80PjjokCgh0o2w5c2U4LhQAE57gj9cz1kzA";
    readonly keytype: "ecdsa-sha2-nistp256";
    readonly scheme: "ecdsa-sha2-nistp256";
    readonly key: "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE1Olb3zMAFFxXKHiIkQO5cJ3Yhl5i6UPp+IhuteBJbuHcA5UogKo0EWtlWwW6KSaKoTNEYL7JlCQiVnkhBktUgg==";
}];
