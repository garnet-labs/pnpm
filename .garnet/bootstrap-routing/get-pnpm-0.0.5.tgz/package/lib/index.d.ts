import { type SigningKey } from './verifySignature.js';
export { type DownloadExecutableOptions, downloadPnpmExecutable } from './downloadExecutable.js';
export { extractTarballMember } from './extractTarballMember.js';
export { isMusl, platformPackageName, type Target } from './platformPackageName.js';
export { DEFAULT_REGISTRY, registryFromEnv, type RequestHeaders, useProxyFromEnv } from './registry.js';
export { type Packument, majorVersion, resolveVersion } from './resolveVersion.js';
export { type PackageSignature, type SigningKey, verifyRegistrySignature } from './verifySignature.js';
export declare function runCli(argv: string[]): Promise<number>;
/**
 * Downloads the pnpm executable and hands over to `pnpm setup`, which installs
 * it globally and puts it on the PATH.
 *
 * Every download is checked against the checksum the registry published for it,
 * and that checksum against npm's signature — see `verifyRegistrySignature`.
 *
 * The temporary directory is assembled to look like the release tarball that
 * https://get.pnpm.io/install.sh downloads — the executable next to its `dist/`
 * tree — because `pnpm setup` installs that directory as-is.
 *
 * @returns the exit code of `pnpm setup`.
 */
export declare function installPnpm(opts: {
    versionSpec: string;
    registry: string;
    keys?: readonly SigningKey[];
}): Promise<number>;
/**
 * Downloads the pnpm executable into `dest`, laid out the way the release
 * tarball lays it out — the executable next to the `dist/` tree it loads.
 *
 * Every download is checked against the checksum the registry published for it,
 * and that checksum against npm's signature; see `verifyRegistrySignature`.
 * Nothing outside `dest` is touched, so a caller that manages its own PATH — a
 * CI action, say — can use this without the global install `installPnpm` does.
 *
 * @returns the version installed and the path to the executable.
 */
export declare function downloadPnpm(opts: {
    versionSpec: string;
    registry: string;
    dest: string;
    keys?: readonly SigningKey[];
}): Promise<{
    version: string;
    binPath: string;
}>;
