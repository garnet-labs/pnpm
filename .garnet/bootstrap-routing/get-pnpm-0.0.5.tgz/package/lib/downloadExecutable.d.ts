import { type RequestHeaders } from './registry.js';
import { type SigningKey } from './verifySignature.js';
export interface DownloadExecutableOptions {
    /** Exact version to download; nothing is resolved against dist-tags. */
    version: string;
    /** Registry to download from, e.g. from {@link registryFromEnv}; a subpath
     * one keeps its subpath whether or not it ends in a slash. */
    registry: string;
    /** Path to place the executable at. */
    destPath: string;
    /** Credentials for `registry`, withheld from any other origin. */
    headers?: RequestHeaders;
    /** Overrides the pinned npm signing keys. */
    keys?: readonly SigningKey[];
    /**
     * Whether the registry's signature over the checksum has to check out;
     * `true` unless set. Waiving it is for a registry that carries no npm
     * signatures — one that re-published the package — and accepts that the
     * checksum then comes from the same host as the bytes it vouches for.
     */
    verifySignature?: boolean;
}
/**
 * Places the pnpm executable for this host at `destPath`, and nothing else.
 *
 * The narrow half of {@link downloadPnpm}, for a caller that already knows the
 * exact version and already has whatever else it needs: no dist-tag lookup (so
 * no packument download), no `dist/` tree, no directory to assemble. Corepack
 * is the case it exists for — it unpacks the `pnpm` package itself but installs
 * none of its dependencies, so the executable has to arrive separately.
 *
 * The download is checked against the checksum the registry published for it,
 * and that checksum against npm's signature, exactly as {@link downloadPnpm}
 * does; nothing is written to `destPath` until both pass. See
 * {@link DownloadExecutableOptions.verifySignature} for the one waiver.
 *
 * Placement is atomic and tolerates losing a race: a concurrent call that got
 * there first keeps its copy, since both placed the same verified bytes.
 *
 * @returns the package the executable came from.
 */
export declare function downloadPnpmExecutable(opts: DownloadExecutableOptions): Promise<{
    packageName: string;
}>;
