/**
 * Whether two paths hold the same bytes.
 *
 * Compared rather than hashed: the answer is usually "no" at the first
 * differing byte, and there is nothing to gain from reading further.
 *
 * `b` is the untrusted side — a path something else may hold — so anything
 * other than a readable regular file of the same size is simply not the same
 * file, rather than an error.
 */
export declare function sameFileContents(a: string, b: string): boolean;
