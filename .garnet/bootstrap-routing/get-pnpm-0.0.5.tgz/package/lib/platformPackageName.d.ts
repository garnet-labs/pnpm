export interface Target {
    /** Major version of the pnpm release being installed. */
    major: number;
    /** `process.platform` of the host. */
    platform: string;
    /** `process.arch` of the host. */
    arch: string;
    /** Whether the host's libc is musl rather than glibc. */
    musl: boolean;
}
/**
 * Name of the npm package that carries the pnpm executable for `target`.
 *
 * pnpm ships the binary in a per-host package that `@pnpm/exe` lists as an
 * optional dependency. The naming scheme changed with the Rust rewrite: v12
 * publishes `@pnpm/exe.<process.platform>-<arch>[-musl]`, while v11 and older
 * publish `@pnpm/<macos|win|linux|linuxstatic>-<arch>`.
 *
 * @throws if pnpm publishes no binary for the host — because the host is not
 * built for at all, because the binary arrived in v12 and an older major was
 * asked for, or because of the v11-only Intel macOS gap.
 */
export declare function platformPackageName({ major, platform, arch, musl }: Target): string;
/**
 * Whether this host's libc is musl rather than glibc.
 *
 * Probed the way pnpm's own wrappers do it rather than through a dependency:
 * glibc builds report a `glibcVersionRuntime`, musl builds leave it unset.
 * Keeping this package dependency-free means `npx` fetches one thing before
 * pnpm exists.
 */
export declare function isMusl(): boolean;
