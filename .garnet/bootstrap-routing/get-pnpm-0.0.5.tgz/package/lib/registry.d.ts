import type { Packument } from './resolveVersion.js';
import type { PackageSignature } from './verifySignature.js';
/** Request headers, for a registry that needs credentials. */
export type RequestHeaders = Record<string, string>;
export interface VersionMeta {
    dist: {
        tarball: string;
        integrity?: string;
        signatures?: PackageSignature[];
    };
}
export declare const DEFAULT_REGISTRY = "https://registry.npmjs.org/";
/** The registry npx/npm is configured with, so a mirror stays a mirror. */
export declare function registryFromEnv(): string;
/**
 * A registry URL that can be used as a base for a relative path.
 *
 * `new URL('pkg', 'https://mirror.example.com/npm')` drops the last segment,
 * so a registry served from a subpath needs its trailing slash to survive.
 */
export declare function normalizeRegistry(registry: string): string;
/**
 * Routes every request made until the returned function is called through the
 * proxy the environment names in `HTTPS_PROXY`/`HTTP_PROXY`, honouring
 * `NO_PROXY`. A no-op when the environment names none.
 *
 * `fetch` reads those variables only when Node was started with
 * `NODE_USE_ENV_PROXY=1`, which nothing that embeds this package controls:
 * Corepack starts the process that runs pnpm's launcher. On a network that
 * allows no other route out, the download then fails with a bare
 * `fetch failed`, while everything before it went through the proxy fine,
 * Corepack's own download of the `pnpm` package included.
 *
 * Node before 24.14 has no way to apply the proxy after startup, so the
 * request goes direct there, as it always has.
 *
 * The setting is process-global, so overlapping downloads share one
 * activation: the first call applies the proxy and the last of the returned
 * functions to run puts the agents back, never one in the middle.
 */
export declare function useProxyFromEnv(): () => void;
export declare function fetchPackument(registry: string, pkgName: string, headers?: RequestHeaders): Promise<Packument>;
export declare function fetchVersionMeta(registry: string, pkgName: string, version: string, headers?: RequestHeaders): Promise<VersionMeta>;
/**
 * Streams `meta.dist.tarball` to `dest`, verifying the checksum the registry
 * published for it. A mismatch removes nothing — the caller discards the whole
 * temporary directory.
 *
 * `registry` re-hosts a tarball URL that points at npm onto that registry, so a
 * mirror that answered the metadata request serves the download too; `headers`
 * travel only to the registry's own origin, never to a download host it names.
 */
export declare function downloadTarball(meta: VersionMeta, dest: string, opts?: TarballOptions): Promise<void>;
export interface TarballOptions {
    /** Registry the metadata came from, to re-host an npm tarball URL onto. */
    registry?: string;
    /** Credentials for `registry`, withheld from any other origin. */
    headers?: RequestHeaders;
}
/**
 * Where to download `meta`'s tarball from.
 *
 * Registries that proxy npm hand back npm's own URL. Following it would leave
 * the mirror the metadata came from — for an air-gapped one, it would not
 * resolve at all — so the path is re-hosted onto `registry`. Matched by origin,
 * so a host that merely starts with npm's is left alone.
 */
export declare function tarballUrl(meta: VersionMeta, registry?: string): URL;
