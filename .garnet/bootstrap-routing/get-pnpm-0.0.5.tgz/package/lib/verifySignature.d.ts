export interface SigningKey {
    keyid: string;
    key: string;
    expires: string | null;
}
export interface PackageSignature {
    keyid: string;
    sig: string;
}
/**
 * Checks the registry's signature over a package's identity and checksum.
 *
 * The registry serves both the tarball and the checksum, so a checksum taken
 * from it proves nothing on its own. This is what makes it worth anything: the
 * signature is made with a key the registry publishes but the download host
 * cannot mint, and the trusted copy of that key ships inside this package.
 *
 * @throws if the package is unsigned, signed with a key that isn't trusted or
 * has expired, or the signature does not verify.
 */
export declare function verifyRegistrySignature(opts: {
    name: string;
    version: string;
    integrity: string;
    signatures?: PackageSignature[];
    keys?: readonly SigningKey[];
    now?: Date;
}): void;
