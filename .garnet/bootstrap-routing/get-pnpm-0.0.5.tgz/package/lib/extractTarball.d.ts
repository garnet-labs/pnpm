/**
 * Unpacks a package tarball into `dest`, leaving its `package/` root in place.
 *
 * Shells out to `tar`, which every supported host has: macOS and Linux ship it,
 * and Windows has had bsdtar since Windows 10 1803. Member selection and
 * `--strip-components` are avoided because busybox tar and bsdtar disagree
 * about them.
 */
export declare function extractTarball(tarball: string, dest: string): void;
