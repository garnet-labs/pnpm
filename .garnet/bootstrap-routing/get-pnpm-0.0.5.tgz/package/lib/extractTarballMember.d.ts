/**
 * Writes one file out of a package tarball to `dest`, and nothing else.
 *
 * Reads the archive in-process rather than shelling out to `tar` the way
 * {@link extractTarball} does: a caller that wants a single executable, in an
 * environment it does not control (a Corepack cache in a minimal image), should
 * not need a `tar` on the PATH for it. Only regular files are considered, which
 * is all an npm tarball holds beyond directories, and the parse stays streaming
 * so the archive never lands in memory.
 *
 * `dest` is created exclusively — an existing file, or a symlink planted at
 * that path, fails the write rather than being followed.
 *
 * @param tarball Path to the gzipped archive.
 * @param memberPath Path of the wanted file inside it, e.g. `package/pnpm`.
 * @param dest Path to write it to.
 * @param mode Permissions for `dest`.
 * @returns whether the member was there.
 */
export declare function extractTarballMember(tarball: string, memberPath: string, dest: string, mode?: number): Promise<boolean>;
